const {init}=require('./api/_lib/db');init().then(x=>{console.log(`OPTIMIZE database ready: ${x.backend} persistent=${x.persistent}`)}).catch(e=>{console.error(e);process.exit(1)});
