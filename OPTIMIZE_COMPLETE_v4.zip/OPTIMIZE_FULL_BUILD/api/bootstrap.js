const { repo }=require('./_lib/db');
const { getSession }=require('./_lib/auth');
const { json,cors }=require('./_lib/http');
module.exports=async function handler(req,res){cors(req,res);if(req.method==='OPTIONS'){res.statusCode=204;return res.end();}try{const r=await repo(),s=await getSession(req);if(!s)return json(res,200,{ok:true,authenticated:false,persistent:r.persistent});const [dashboard,integrations]=await Promise.all([r.dashboard(s.tenant_id),r.listIntegrations(s.tenant_id)]);return json(res,200,{ok:true,authenticated:true,persistent:r.persistent,user:{id:s.user_id,email:s.email,name:s.name,tenantId:s.tenant_id},dashboard,integrations});}catch(e){return json(res,500,{ok:false,error:e.message||String(e)});}};
