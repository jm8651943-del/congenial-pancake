const { fetchJson } = require('./_lib/radar');
module.exports = async function handler(req, res) {
  if (req.method !== 'GET') { res.statusCode = 405; return res.end(JSON.stringify({ok:false,error:'GET only'})); }
  try {
    const url = new URL(req.url, 'http://localhost');
    const cikRaw = (url.searchParams.get('cik') || '').replace(/\D/g, '');
    if (!cikRaw) { res.statusCode = 400; return res.end(JSON.stringify({ok:false,error:'cik is required'})); }
    const cik = cikRaw.padStart(10, '0');
    const data = await fetchJson(`https://data.sec.gov/submissions/CIK${cik}.json`, {
      headers: { 'User-Agent': process.env.SEC_USER_AGENT || 'OPTIMIZE-PrimeForge/1.0' }
    });
    res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.setHeader('Vary', 'Origin');
  res.statusCode = 200;
    res.setHeader('Content-Type','application/json; charset=utf-8');
    res.setHeader('Cache-Control','s-maxage=300, stale-while-revalidate=900');
    res.end(JSON.stringify({ok:true,cik,data}));
  } catch (error) {
    res.statusCode = 502;
    res.setHeader('Content-Type','application/json; charset=utf-8');
    res.end(JSON.stringify({ok:false,error:error.message}));
  }
};
