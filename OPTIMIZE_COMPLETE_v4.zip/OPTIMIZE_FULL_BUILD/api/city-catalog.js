const { fetchJson } = require('./_lib/radar');
module.exports = async function handler(req, res) {
  if (req.method !== 'GET') { res.statusCode = 405; return res.end(JSON.stringify({ok:false,error:'GET only'})); }
  try {
    const url = new URL(req.url, 'http://localhost');
    const target = new URL('https://opendata-cosagis.opendata.arcgis.com/api/search/v1/catalog');
    for (const k of ['q','limit','bbox','type']) if (url.searchParams.get(k)) target.searchParams.set(k, url.searchParams.get(k));
    const data = await fetchJson(target.toString());
    res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || '*');
  res.setHeader('Vary', 'Origin');
  res.statusCode = 200; res.setHeader('Content-Type','application/json; charset=utf-8');
    res.end(JSON.stringify(data));
  } catch (error) {
    res.statusCode = 502; res.setHeader('Content-Type','application/json; charset=utf-8'); res.end(JSON.stringify({ok:false,error:error.message}));
  }
};
