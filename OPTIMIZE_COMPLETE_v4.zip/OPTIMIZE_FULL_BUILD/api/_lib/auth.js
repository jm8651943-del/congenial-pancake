const crypto = require('node:crypto');
const { repo, hash } = require('./db');
const COOKIE = 'optimize_session';
const TTL_MS = 1000 * 60 * 60 * 24 * 14;

function parseCookies(req){const raw=req.headers?.cookie||'';const out={};for(const part of raw.split(';')){const i=part.indexOf('=');if(i<0)continue;out[part.slice(0,i).trim()]=decodeURIComponent(part.slice(i+1).trim());}return out;}
function cookie(value,maxAge=TTL_MS/1000){const secure=process.env.NODE_ENV==='production' || String(process.env.APP_URL||'').startsWith('https://');return `${COOKIE}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(maxAge)}${secure?'; Secure':''}`;}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){const derived=crypto.pbkdf2Sync(password,salt,120000,32,'sha256').toString('hex');return `pbkdf2$120000$${salt}$${derived}`;}
function verifyPassword(password,stored){const p=String(stored||'').split('$');if(p.length!==4||p[0]!=='pbkdf2')return false;const actual=crypto.pbkdf2Sync(password,p[2],Number(p[1]),32,'sha256').toString('hex');return crypto.timingSafeEqual(Buffer.from(actual),Buffer.from(p[3]));}
function strongEnough(password){return typeof password==='string'&&password.length>=8;}
async function loginSession(req,res,userId){const r=await repo();const token=crypto.randomBytes(32).toString('base64url');const tokenHash=hash(token);const expiresAt=new Date(Date.now()+TTL_MS).toISOString();await r.createSession({userId,tokenHash,expiresAt});res.setHeader('Set-Cookie',cookie(token));}
async function destroySession(req,res){const token=parseCookies(req)[COOKIE];if(token){const r=await repo();await r.deleteSession(hash(token));}res.setHeader('Set-Cookie',cookie('',0));}
async function getSession(req){const token=parseCookies(req)[COOKIE];if(!token)return null;const r=await repo();return r.getSession(hash(token));}
async function requireUser(req,res){const session=await getSession(req);if(!session){res.statusCode=401;res.setHeader('Content-Type','application/json');res.end(JSON.stringify({ok:false,error:'AUTH_REQUIRED'}));return null;}return session;}
module.exports={COOKIE,cookie,hashPassword,verifyPassword,strongEnough,loginSession,destroySession,getSession,requireUser,parseCookies};
