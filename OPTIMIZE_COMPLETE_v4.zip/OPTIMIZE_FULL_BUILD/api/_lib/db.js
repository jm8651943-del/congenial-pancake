const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const DATA_PATH = process.env.LOCAL_DATA_PATH || path.join(process.cwd(), 'data', 'optimize.local.json');
const DATABASE_URL = process.env.DATABASE_URL || '';
let pgPromise;
let initialized = false;

function id() { return crypto.randomUUID(); }
function now() { return new Date().toISOString(); }
function hash(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS tenants (id text PRIMARY KEY, name text NOT NULL, slug text UNIQUE NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS users (id text PRIMARY KEY, email text UNIQUE NOT NULL, name text NOT NULL, password_hash text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS memberships (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE, role text NOT NULL DEFAULT 'owner', UNIQUE(tenant_id,user_id));
CREATE TABLE IF NOT EXISTS sessions (id text PRIMARY KEY, user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE, token_hash text UNIQUE NOT NULL, expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS oauth_states (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE, provider text NOT NULL, state_hash text UNIQUE NOT NULL, verifier text, expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS opportunities (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, title text NOT NULL, company text, description text, source text, source_record_id text, status text NOT NULL DEFAULT 'NEW', score integer NOT NULL DEFAULT 0, confidence text, amount numeric, lat double precision, lon double precision, trades jsonb NOT NULL DEFAULT '[]'::jsonb, metadata jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS opportunities_tenant_status_idx ON opportunities(tenant_id,status);
CREATE INDEX IF NOT EXISTS opportunities_tenant_score_idx ON opportunities(tenant_id,score DESC);
CREATE TABLE IF NOT EXISTS tasks (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, opportunity_id text REFERENCES opportunities(id) ON DELETE SET NULL, title text NOT NULL, due_at timestamptz, priority text NOT NULL DEFAULT 'MEDIUM', status text NOT NULL DEFAULT 'OPEN', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS tasks_tenant_status_idx ON tasks(tenant_id,status);
CREATE TABLE IF NOT EXISTS activities (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, opportunity_id text REFERENCES opportunities(id) ON DELETE SET NULL, type text NOT NULL, body text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS radar_scans (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, user_id text REFERENCES users(id) ON DELETE SET NULL, query text, scope text, days integer, returned integer, stats jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS radar_signals (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, scan_id text REFERENCES radar_scans(id) ON DELETE CASCADE, fingerprint text NOT NULL, title text NOT NULL, source text, source_record_id text, score integer, confidence text, lat double precision, lon double precision, payload jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS radar_signals_tenant_score_idx ON radar_signals(tenant_id,score DESC);
CREATE TABLE IF NOT EXISTS integrations (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, provider text NOT NULL, status text NOT NULL DEFAULT 'disconnected', metadata jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,provider));
CREATE TABLE IF NOT EXISTS subscriptions (id text PRIMARY KEY, tenant_id text NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, provider text NOT NULL, status text NOT NULL DEFAULT 'inactive', customer_id text, subscription_id text, price_id text, current_period_end timestamptz, metadata jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,provider));
`;

function createLocalState() {
  return { tenants: [], users: [], memberships: [], sessions: [], oauth_states: [], opportunities: [], tasks: [], activities: [], radar_scans: [], radar_signals: [], integrations: [], subscriptions: [] };
}
async function ensureLocal() {
  await fs.mkdir(path.dirname(DATA_PATH), { recursive: true });
  try { await fs.access(DATA_PATH); }
  catch { await fs.writeFile(DATA_PATH, JSON.stringify(createLocalState(), null, 2)); }
}
async function readLocal() { await ensureLocal(); return JSON.parse(await fs.readFile(DATA_PATH, 'utf8')); }
async function writeLocal(state) {
  await fs.mkdir(path.dirname(DATA_PATH), { recursive: true });
  const temp = `${DATA_PATH}.${process.pid}.tmp`;
  await fs.writeFile(temp, JSON.stringify(state, null, 2));
  await fs.rename(temp, DATA_PATH);
}

async function pg() {
  if (!pgPromise) pgPromise = import('@neondatabase/serverless').then(m => m.neon);
  const neon = await pgPromise;
  return neon(DATABASE_URL);
}

async function init() {
  if (initialized) return { persistent: Boolean(DATABASE_URL), backend: DATABASE_URL ? 'neon-postgres' : 'local-json' };
  if (DATABASE_URL) {
    const sql = await pg();
    await sql.query(SCHEMA_SQL);
  } else {
    await ensureLocal();
  }
  initialized = true;
  return { persistent: Boolean(DATABASE_URL), backend: DATABASE_URL ? 'neon-postgres' : 'local-json' };
}

function publicUser(r) { return r ? { id: r.id, email: r.email, name: r.name, tenantId: r.tenant_id || r.tenantId } : null; }

async function repo() {
  await init();
  if (!DATABASE_URL) return localRepo();
  const sql = await pg();
  return {
    persistent: true,
    async getUserByEmail(email) { const r = await sql`SELECT u.*, m.tenant_id FROM users u JOIN memberships m ON m.user_id=u.id WHERE lower(u.email)=lower(${email}) LIMIT 1`; return r[0] || null; },
    async getUserById(userId) { const r = await sql`SELECT u.*, m.tenant_id FROM users u JOIN memberships m ON m.user_id=u.id WHERE u.id=${userId} LIMIT 1`; return r[0] || null; },
    async createUserWithTenant({ email, name, passwordHash, tenantName }) { const uid=id(), tid=id(), mid=id(), slug=(slugify(tenantName)||'tenant')+'-'+uid.slice(0,8); await sql.query(`WITH t AS (INSERT INTO tenants (id,name,slug) VALUES ($1,$2,$3) RETURNING id), u AS (INSERT INTO users (id,email,name,password_hash) VALUES ($4,lower($5),$6,$7) RETURNING id) INSERT INTO memberships (id,tenant_id,user_id,role) SELECT $8,t.id,u.id,'owner' FROM t,u`, [tid,tenantName,slug,uid,email,name,passwordHash,mid]); return { userId: uid, tenantId: tid, email, name }; },
    async createSession({ userId, tokenHash, expiresAt }) { const sid=id(); await sql`INSERT INTO sessions (id,user_id,token_hash,expires_at) VALUES (${sid},${userId},${tokenHash},${expiresAt})`; return sid; },
    async getSession(tokenHash) { const r=await sql`SELECT s.*,u.email,u.name,m.tenant_id FROM sessions s JOIN users u ON u.id=s.user_id JOIN memberships m ON m.user_id=u.id WHERE s.token_hash=${tokenHash} AND s.expires_at>now() LIMIT 1`; return r[0]||null; },
    async deleteSession(tokenHash) { await sql`DELETE FROM sessions WHERE token_hash=${tokenHash}`; },
    async listOpportunities(tenantId, { status, q, limit=100 }) { const lim=Math.min(Math.max(Number(limit)||100,1),200); let r; if(status&&q) r=await sql`SELECT * FROM opportunities WHERE tenant_id=${tenantId} AND status=${status} AND (title ILIKE ${'%'+q+'%'} OR company ILIKE ${'%'+q+'%'}) ORDER BY score DESC,updated_at DESC LIMIT ${lim}`; else if(status) r=await sql`SELECT * FROM opportunities WHERE tenant_id=${tenantId} AND status=${status} ORDER BY score DESC,updated_at DESC LIMIT ${lim}`; else if(q) r=await sql`SELECT * FROM opportunities WHERE tenant_id=${tenantId} AND (title ILIKE ${'%'+q+'%'} OR company ILIKE ${'%'+q+'%'}) ORDER BY score DESC,updated_at DESC LIMIT ${lim}`; else r=await sql`SELECT * FROM opportunities WHERE tenant_id=${tenantId} ORDER BY score DESC,updated_at DESC LIMIT ${lim}`; return r.map(normalizePgOpportunity); },
    async createOpportunity(tenantId, x) { const oid=id(); await sql`INSERT INTO opportunities (id,tenant_id,title,company,description,source,source_record_id,status,score,confidence,amount,lat,lon,trades,metadata) VALUES (${oid},${tenantId},${x.title},${x.company||null},${x.description||null},${x.source||null},${x.sourceRecordId||null},${x.status||'NEW'},${Number(x.score)||0},${x.confidence||null},${x.amount==null?null:Number(x.amount)},${x.lat==null?null:Number(x.lat)},${x.lon==null?null:Number(x.lon)},${JSON.stringify(x.trades||[])},${JSON.stringify(x.metadata||{})})`; const r=await sql`SELECT * FROM opportunities WHERE id=${oid}`; return normalizePgOpportunity(r[0]); },
    async updateOpportunity(tenantId, oid, patch) { const allowed=['title','company','description','status','score','confidence','amount','lat','lon']; const sets=[]; const values=[]; for(const k of allowed) if(patch[k]!==undefined){ values.push(patch[k]); sets.push(k); } if(patch.trades!==undefined){ values.push(JSON.stringify(patch.trades)); sets.push('trades'); } if(patch.metadata!==undefined){ values.push(JSON.stringify(patch.metadata)); sets.push('metadata'); } if(!sets.length) return null; let i=0; const assigns=sets.map(k=>{const v=values[i++]; return k==='score'||k==='amount'||k==='lat'||k==='lon'?sql.unsafe(`${k} = $${i}`, [v]):sql.unsafe(`${k} = $${i}`, [v])}); /* guarded below with dynamic SQL */ const params=[]; const fragments=[]; for(const k of sets){ const v=patch[k]; params.push(v); const cast=['trades','metadata'].includes(k)?'::jsonb':''; fragments.push(`${k} = $${params.length}${cast}`); } params.push(tenantId,oid); const textSql=`UPDATE opportunities SET ${fragments.join(', ')}, updated_at=now() WHERE tenant_id=$${params.length-1} AND id=$${params.length} RETURNING *`; const r=await sql.query(textSql, params); return normalizePgOpportunity(r[0]); },
    async listTasks(tenantId, { status, limit=100 }) { const lim=Math.min(Math.max(Number(limit)||100,1),200); let r=status?await sql`SELECT * FROM tasks WHERE tenant_id=${tenantId} AND status=${status} ORDER BY due_at NULLS LAST,created_at DESC LIMIT ${lim}`:await sql`SELECT * FROM tasks WHERE tenant_id=${tenantId} ORDER BY due_at NULLS LAST,created_at DESC LIMIT ${lim}`; return r; },
    async createTask(tenantId,x) { const tid=id(); await sql`INSERT INTO tasks (id,tenant_id,opportunity_id,title,due_at,priority,status) VALUES (${tid},${tenantId},${x.opportunityId||null},${x.title},${x.dueAt||null},${x.priority||'MEDIUM'},${x.status||'OPEN'})`; const r=await sql`SELECT * FROM tasks WHERE id=${tid}`; return r[0]; },
    async updateTask(tenantId, tid, patch) { const keys=['title','opportunity_id','due_at','priority','status']; const params=[],frags=[]; for(const k of keys){ if(patch[k]!==undefined){params.push(patch[k]);frags.push(`${k}=$${params.length}`);} } if(!frags.length)return null; params.push(tenantId,tid); const r=await sql.query(`UPDATE tasks SET ${frags.join(', ')},updated_at=now() WHERE tenant_id=$${params.length-1} AND id=$${params.length} RETURNING *`,params); return r[0]||null; },
    async dashboard(tenantId) { const [o,t,a,s]=await Promise.all([sql`SELECT status, count(*)::int count, coalesce(sum(amount),0)::numeric total FROM opportunities WHERE tenant_id=${tenantId} GROUP BY status`, sql`SELECT count(*)::int open FROM tasks WHERE tenant_id=${tenantId} AND status <> 'DONE'`, sql`SELECT count(*)::int count FROM activities WHERE tenant_id=${tenantId}`, sql`SELECT count(*)::int count FROM radar_scans WHERE tenant_id=${tenantId}`]); return { pipeline:o, openTasks:t[0]?.open||0, activities:a[0]?.count||0, scans:s[0]?.count||0 }; },
    async addActivity(tenantId,x){const aid=id();await sql`INSERT INTO activities(id,tenant_id,opportunity_id,type,body) VALUES(${aid},${tenantId},${x.opportunityId||null},${x.type},${x.body})`;return {id:aid,...x};},
    async saveRadarScan(tenantId,userId,data){const sid=id();await sql`INSERT INTO radar_scans(id,tenant_id,user_id,query,scope,days,returned,stats) VALUES(${sid},${tenantId},${userId||null},${data.query},${data.scope},${data.days},${data.returned},${JSON.stringify(data.stats||{})})`; for(const s of (data.signals||[])){const rid=id(),fp=hash(`${s.source}|${s.sourceRecordId||s.id}|${s.title}|${s.lat}|${s.lon}`);await sql`INSERT INTO radar_signals(id,tenant_id,scan_id,fingerprint,title,source,source_record_id,score,confidence,lat,lon,payload) VALUES(${rid},${tenantId},${sid},${fp},${s.title},${s.source||null},${s.sourceRecordId||null},${s.score||0},${s.confidence||null},${s.lat??null},${s.lon??null},${JSON.stringify(s)})`; } return sid;},
    async listIntegrations(tenantId){const r=await sql`SELECT * FROM integrations WHERE tenant_id=${tenantId} ORDER BY provider`;return r;},
    async upsertIntegration(tenantId,provider,status,metadata={}){const iid=id();const r=await sql`INSERT INTO integrations(id,tenant_id,provider,status,metadata) VALUES(${iid},${tenantId},${provider},${status},${JSON.stringify(metadata)}) ON CONFLICT(tenant_id,provider) DO UPDATE SET status=EXCLUDED.status,metadata=EXCLUDED.metadata,updated_at=now() RETURNING *`;return r[0];},
    async getIntegration(tenantId,provider){const r=await sql`SELECT * FROM integrations WHERE tenant_id=${tenantId} AND provider=${provider} LIMIT 1`;return r[0]||null;},
    async createOAuthState(x){const oid=id();await sql`INSERT INTO oauth_states(id,tenant_id,user_id,provider,state_hash,verifier,expires_at) VALUES(${oid},${x.tenantId},${x.userId},${x.provider},${x.stateHash},${x.verifier||null},${x.expiresAt})`;return oid;},
    async getOAuthState(stateHash){const r=await sql`SELECT * FROM oauth_states WHERE state_hash=${stateHash} AND expires_at>now() LIMIT 1`;return r[0]||null;},
    async deleteOAuthState(stateHash){await sql`DELETE FROM oauth_states WHERE state_hash=${stateHash}`;},
    async upsertSubscription(tenantId,x){const iid=id();const r=await sql`INSERT INTO subscriptions(id,tenant_id,provider,status,customer_id,subscription_id,price_id,current_period_end,metadata) VALUES(${iid},${tenantId},${x.provider},${x.status||'inactive'},${x.customerId||null},${x.subscriptionId||null},${x.priceId||null},${x.currentPeriodEnd||null},${JSON.stringify(x.metadata||{})}) ON CONFLICT(tenant_id,provider) DO UPDATE SET status=EXCLUDED.status,customer_id=EXCLUDED.customer_id,subscription_id=EXCLUDED.subscription_id,price_id=EXCLUDED.price_id,current_period_end=EXCLUDED.current_period_end,metadata=EXCLUDED.metadata,updated_at=now() RETURNING *`;return r[0];},
    async getSubscription(tenantId,provider){const r=await sql`SELECT * FROM subscriptions WHERE tenant_id=${tenantId} AND provider=${provider} LIMIT 1`;return r[0]||null;},
    async tenantUsers(tenantId){const r=await sql`SELECT u.id,u.email,u.name,m.role FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.tenant_id=${tenantId}`;return r;},
    async listTenants(){return await sql`SELECT id,name,slug,created_at FROM tenants ORDER BY created_at`;},
  };
}

function normalizePgOpportunity(r){ if(!r)return null; return {...r, trades:typeof r.trades==='string'?JSON.parse(r.trades):r.trades, metadata:typeof r.metadata==='string'?JSON.parse(r.metadata):r.metadata, amount:r.amount==null?null:Number(r.amount), tenantId:r.tenant_id, sourceRecordId:r.source_record_id}; }
function slugify(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,50);}

function localRepo(){
  return { persistent:false,
    async getUserByEmail(email){const s=await readLocal();const u=s.users.find(x=>x.email.toLowerCase()===email.toLowerCase());if(!u)return null;const m=s.memberships.find(x=>x.user_id===u.id);return {...u,tenant_id:m?.tenant_id||null};},
    async getUserById(userId){const s=await readLocal();const u=s.users.find(x=>x.id===userId);if(!u)return null;const m=s.memberships.find(x=>x.user_id===u.id);return {...u,tenant_id:m?.tenant_id||null};},
    async createUserWithTenant(x){const s=await readLocal();if(s.users.some(u=>u.email.toLowerCase()===x.email.toLowerCase()))throw new Error('EMAIL_EXISTS');const uid=id(),tid=id();s.tenants.push({id:tid,name:x.tenantName,slug:slugify(x.tenantName)||`tenant-${uid.slice(0,8)}`,created_at:now()});s.users.push({id:uid,email:x.email.toLowerCase(),name:x.name,password_hash:x.passwordHash,created_at:now()});s.memberships.push({id:id(),tenant_id:tid,user_id:uid,role:'owner'});await writeLocal(s);return {userId:uid,tenantId:tid,email:x.email,name:x.name};},
    async createSession(x){const s=await readLocal();const sid=id();s.sessions.push({id:sid,user_id:x.userId,token_hash:x.tokenHash,expires_at:x.expiresAt,created_at:now()});await writeLocal(s);return sid;},
    async getSession(tokenHash){const s=await readLocal();const row=s.sessions.find(x=>x.token_hash===tokenHash&&new Date(x.expires_at)>new Date());if(!row)return null;const u=s.users.find(x=>x.id===row.user_id),m=s.memberships.find(x=>x.user_id===row.user_id);return row&&u&&m?{...row,email:u.email,name:u.name,tenant_id:m.tenant_id}:null;},
    async deleteSession(tokenHash){const s=await readLocal();s.sessions=s.sessions.filter(x=>x.token_hash!==tokenHash);await writeLocal(s);},
    async listOpportunities(tenantId,{status,q,limit=100}){const s=await readLocal();let rows=s.opportunities.filter(x=>x.tenant_id===tenantId);if(status)rows=rows.filter(x=>x.status===status);if(q){const h=q.toLowerCase();rows=rows.filter(x=>`${x.title} ${x.company||''}`.toLowerCase().includes(h));}return rows.sort((a,b)=>(b.score||0)-(a.score||0)).slice(0,Math.min(Math.max(Number(limit)||100,1),200)).map(normalizeLocalOpportunity);},
    async createOpportunity(tenantId,x){const s=await readLocal();const row={id:id(),tenant_id:tenantId,title:x.title,company:x.company||null,description:x.description||null,source:x.source||null,source_record_id:x.sourceRecordId||null,status:x.status||'NEW',score:Number(x.score)||0,confidence:x.confidence||null,amount:x.amount==null?null:Number(x.amount),lat:x.lat==null?null:Number(x.lat),lon:x.lon==null?null:Number(x.lon),trades:x.trades||[],metadata:x.metadata||{},created_at:now(),updated_at:now()};s.opportunities.push(row);await writeLocal(s);return normalizeLocalOpportunity(row);},
    async updateOpportunity(tenantId,oid,patch){const s=await readLocal();const r=s.opportunities.find(x=>x.id===oid&&x.tenant_id===tenantId);if(!r)return null;for(const k of ['title','company','description','status','score','confidence','amount','lat','lon','trades','metadata'])if(patch[k]!==undefined)r[k]=patch[k];r.updated_at=now();await writeLocal(s);return normalizeLocalOpportunity(r);},
    async listTasks(tenantId,{status,limit=100}){const s=await readLocal();let r=s.tasks.filter(x=>x.tenant_id===tenantId);if(status)r=r.filter(x=>x.status===status);return r.sort((a,b)=>String(a.due_at||'').localeCompare(String(b.due_at||''))).slice(0,Math.min(Math.max(Number(limit)||100,1),200));},
    async createTask(tenantId,x){const s=await readLocal();const r={id:id(),tenant_id:tenantId,opportunity_id:x.opportunityId||null,title:x.title,due_at:x.dueAt||null,priority:x.priority||'MEDIUM',status:x.status||'OPEN',created_at:now(),updated_at:now()};s.tasks.push(r);await writeLocal(s);return r;},
    async updateTask(tenantId,tid,patch){const s=await readLocal();const r=s.tasks.find(x=>x.id===tid&&x.tenant_id===tenantId);if(!r)return null;for(const k of ['title','opportunity_id','due_at','priority','status'])if(patch[k]!==undefined)r[k]=patch[k];r.updated_at=now();await writeLocal(s);return r;},
    async dashboard(tenantId){const s=await readLocal();const o=s.opportunities.filter(x=>x.tenant_id===tenantId),t=s.tasks.filter(x=>x.tenant_id===tenantId&&x.status!=='DONE'),a=s.activities.filter(x=>x.tenant_id===tenantId),sc=s.radar_scans.filter(x=>x.tenant_id===tenantId);const by={};for(const r of o){if(!by[r.status])by[r.status]={status:r.status,count:0,total:0};by[r.status].count++;by[r.status].total+=Number(r.amount)||0;}return {pipeline:Object.values(by),openTasks:t.length,activities:a.length,scans:sc.length};},
    async addActivity(tenantId,x){const s=await readLocal();const r={id:id(),tenant_id:tenantId,...x,created_at:now()};s.activities.push(r);await writeLocal(s);return r;},
    async saveRadarScan(tenantId,userId,data){const s=await readLocal(),sid=id();s.radar_scans.push({id:sid,tenant_id:tenantId,user_id:userId||null,query:data.query,scope:data.scope,days:data.days,returned:data.returned,stats:data.stats||{},created_at:now()});for(const z of (data.signals||[])){s.radar_signals.push({id:id(),tenant_id:tenantId,scan_id:sid,fingerprint:hash(`${z.source}|${z.sourceRecordId||z.id}|${z.title}|${z.lat}|${z.lon}`),title:z.title,source:z.source||null,source_record_id:z.sourceRecordId||null,score:z.score||0,confidence:z.confidence||null,lat:z.lat??null,lon:z.lon??null,payload:z,created_at:now()});}await writeLocal(s);return sid;},
    async listIntegrations(tenantId){const s=await readLocal();return s.integrations.filter(x=>x.tenant_id===tenantId);},
    async upsertIntegration(tenantId,provider,status,metadata={}){const s=await readLocal();let r=s.integrations.find(x=>x.tenant_id===tenantId&&x.provider===provider);if(!r){r={id:id(),tenant_id:tenantId,provider,status,metadata,created_at:now(),updated_at:now()};s.integrations.push(r);}else{r.status=status;r.metadata=metadata;r.updated_at=now();}await writeLocal(s);return r;},
    async getIntegration(tenantId,provider){const s=await readLocal();return s.integrations.find(x=>x.tenant_id===tenantId&&x.provider===provider)||null;},
    async createOAuthState(x){const s=await readLocal();const r={id:id(),tenant_id:x.tenantId,user_id:x.userId,provider:x.provider,state_hash:x.stateHash,verifier:x.verifier||null,expires_at:x.expiresAt,created_at:now()};s.oauth_states.push(r);await writeLocal(s);return r.id;},
    async getOAuthState(stateHash){const s=await readLocal();return s.oauth_states.find(x=>x.state_hash===stateHash&&new Date(x.expires_at)>new Date())||null;},
    async deleteOAuthState(stateHash){const s=await readLocal();s.oauth_states=s.oauth_states.filter(x=>x.state_hash!==stateHash);await writeLocal(s);},
    async upsertSubscription(tenantId,x){const s=await readLocal();let r=s.subscriptions.find(row=>row.tenant_id===tenantId&&row.provider===x.provider);if(!r){r={id:id(),tenant_id:tenantId,provider:x.provider,status:x.status||'inactive',customer_id:x.customerId||null,subscription_id:x.subscriptionId||null,price_id:x.priceId||null,current_period_end:x.currentPeriodEnd||null,metadata:x.metadata||{},created_at:now(),updated_at:now()};s.subscriptions.push(r);}else{Object.assign(r,{status:x.status||r.status,customer_id:x.customerId||r.customer_id,subscription_id:x.subscriptionId||r.subscription_id,price_id:x.priceId||r.price_id,current_period_end:x.currentPeriodEnd||r.current_period_end,metadata:x.metadata||r.metadata,updated_at:now()});}await writeLocal(s);return r;},
    async getSubscription(tenantId,provider){const s=await readLocal();return s.subscriptions.find(x=>x.tenant_id===tenantId&&x.provider===provider)||null;},
    async tenantUsers(tenantId){const s=await readLocal();const mids=s.memberships.filter(m=>m.tenant_id===tenantId);return mids.map(m=>{const u=s.users.find(x=>x.id===m.user_id);return {id:u.id,email:u.email,name:u.name,role:m.role};});},
    async listTenants(){const s=await readLocal();return s.tenants;}
  };
}
function normalizeLocalOpportunity(r){return r?{...r,tenantId:r.tenant_id,sourceRecordId:r.source_record_id}:null;}
module.exports={repo,init,hash,publicUser,DATA_PATH};
