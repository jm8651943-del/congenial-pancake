const crypto=require('node:crypto');
function key(){const secret=process.env.APP_ENCRYPTION_KEY;if(!secret)throw new Error('APP_ENCRYPTION_KEY_REQUIRED');return crypto.createHash('sha256').update(secret).digest();}
function encrypt(value){const iv=crypto.randomBytes(12),cipher=crypto.createCipheriv('aes-256-gcm',key(),iv);const data=Buffer.concat([cipher.update(String(value),'utf8'),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),data]).toString('base64url');}
function decrypt(payload){const b=Buffer.from(payload,'base64url');const iv=b.subarray(0,12),tag=b.subarray(12,28),data=b.subarray(28);const decipher=crypto.createDecipheriv('aes-256-gcm',key(),iv);decipher.setAuthTag(tag);return Buffer.concat([decipher.update(data),decipher.final()]).toString('utf8');}
module.exports={encrypt,decrypt};
