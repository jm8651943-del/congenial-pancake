const USER_AGENT = process.env.SEC_USER_AGENT || 'OPTIMIZE-PrimeForge/1.0';

const SAN_ANTONIO_CENTER = { lat: 29.4241, lon: -98.4936 };

const SOURCES = {
  sanAntonio311: {
    id: 'cosa-311', name: 'City of San Antonio 311', kind: 'city', auth: 'public', priority: 1,
    capabilities: ['signals', 'geospatial', 'recency'],
    url: 'https://services.arcgis.com/g1fRTDLeMgspWrYp/ArcGIS/rest/services/311_All_Service_Calls/FeatureServer/0/query',
  },
  sanAntonioPlans: {
    id: 'cosa-plan-review', name: 'San Antonio Preliminary Plan Review', kind: 'city', auth: 'public', priority: 1,
    capabilities: ['signals', 'geospatial', 'development', 'economic'],
    url: 'https://services.arcgis.com/g1fRTDLeMgspWrYp/ArcGIS/rest/services/Preliminary_Plan_Review_Meetings/FeatureServer/0/query',
  },
  sanAntonioCatalog: {
    id: 'cosa-open-data', name: 'City of San Antonio Open Data Search API', kind: 'city', auth: 'public', priority: 2,
    capabilities: ['discovery'],
    url: 'https://opendata-cosagis.opendata.arcgis.com/api/search/v1/catalog',
  },
  bexarStormwater: {
    id: 'bexar-stormwater', name: 'Bexar County Stormwater Permits', kind: 'county', auth: 'public', priority: 1,
    capabilities: ['signals', 'geospatial', 'development'],
    url: 'https://maps.bexar.org/arcgis/rest/services/PW/SWQ_Permits/MapServer/0/query',
  },
  bexarCapitalProjects: {
    id: 'bexar-capital-projects', name: 'Bexar County Capital Projects', kind: 'county', auth: 'public', priority: 1,
    capabilities: ['signals', 'geospatial', 'infrastructure', 'economic'],
    url: 'https://maps.bexar.org/arcgis/rest/services/PW/Capital_Projects/MapServer/0/query',
  },
  bexarPlatApplications: {
    id: 'bexar-plat-applications', name: 'Bexar County Plat Applications', kind: 'county', auth: 'public', priority: 1,
    capabilities: ['signals', 'geospatial', 'development'],
    url: 'https://maps.bexar.org/arcgis/rest/services/PW/PlatsMDPs/MapServer/4/query',
  },
  dataGov: {
    id: 'datagov', name: 'Data.gov Catalog API', kind: 'federal', auth: 'public', priority: 3,
    capabilities: ['discovery'],
    url: 'https://catalog.data.gov/api/3/action/package_search',
  },
  usaSpending: {
    id: 'usaspending', name: 'USAspending API', kind: 'federal', auth: 'public', priority: 2,
    capabilities: ['signals', 'economic'],
    url: 'https://api.usaspending.gov/api/v2/search/spending_by_award/',
  },
  sec: {
    id: 'sec-edgar', name: 'SEC EDGAR data.sec.gov', kind: 'federal', auth: 'public-user-agent', priority: 3,
    capabilities: ['enrichment', 'corporate'],
    url: 'https://data.sec.gov/submissions/',
  },
  sam: {
    id: 'sam-opportunities', name: 'SAM.gov Opportunities API', kind: 'federal', auth: 'api-key', priority: 1,
    capabilities: ['signals', 'procurement', 'economic'],
    url: 'https://api.sam.gov/opportunities/v2/search',
  },
};

const TRADE_TERMS = {
  hvac: ['hvac', 'air conditioning', 'air-conditioning', 'heating', 'heat pump', 'mechanical', 'refrigeration'],
  plumbing: ['plumbing', 'plumber', 'sewer', 'water line', 'drain', 'backflow'],
  electrical: ['electrical', 'electrician', 'power', 'lighting', 'switchgear', 'generator'],
  roofing: ['roof', 'roofing', 'shingle', 'leak', 'water intrusion', 'roof deck'],
  tree: ['tree', 'downed tree', 'branch', 'brush', 'overgrowth', 'stump', 'arbor'],
  exterior: ['fence', 'sidewalk', 'driveway', 'concrete', 'pavement', 'curb', 'gutter', 'siding'],
  propertyMaintenance: ['property maintenance', 'dangerous building', 'vacant', 'graffiti', 'litter', 'debris', 'weeds'],
  construction: ['construction', 'renovation', 'remodel', 'addition', 'development', 'site work', 'tenant improvement'],
  stormwater: ['stormwater', 'drainage', 'detention', 'erosion', 'flood control', 'culvert'],
  infrastructure: ['road', 'arterial', 'bridge', 'intersection', 'signal', 'transportation', 'capital improvement'],
};

const SOURCE_WEIGHT = Object.fromEntries(Object.values(SOURCES).map(s => [s.id, s.priority === 1 ? 5 : s.priority === 2 ? 3 : 2]));
const STOP_WORDS = new Set(['the','and','for','with','from','that','this','san','antonio','county','city','project','service','request','plan','review']);

function normalizeText(value) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

function normalizeNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function tradeMatches(text, keywords = Object.keys(TRADE_TERMS)) {
  const hay = normalizeText(text).toLowerCase();
  const matches = [];
  for (const trade of keywords) {
    const terms = TRADE_TERMS[trade] || [];
    if (terms.some(term => hay.includes(term))) matches.push(trade);
  }
  return matches;
}

function recencyScore(dateValue, days = 30) {
  const t = Date.parse(dateValue || '');
  if (!Number.isFinite(t)) return 0;
  const ageDays = Math.max(0, (Date.now() - t) / 86400000);
  const horizon = Math.max(1, Number(days) || 30);
  return Math.max(0, Math.round(25 * (1 - Math.min(ageDays / horizon, 1))));
}

function intentScore(signal) {
  const text = [signal.title, signal.description, signal.category, signal.type, signal.status].join(' ').toLowerCase();
  let score = 0;
  if (/permit|plan review|bid|procurement|award|application|construction|replacement|repair|project/.test(text)) score += 12;
  if (/scheduled|issued|approved|advertise|bid date|start date|anticipated/.test(text)) score += 5;
  if (/open|active|pending|submitted|accepted/.test(text)) score += 3;
  if (/closed|cancelled|retired|complete|completed/.test(text)) score -= 5;
  return Math.max(0, Math.min(20, score));
}

function economicScore(signal) {
  const amount = normalizeNumber(signal.amount ?? signal.estimatedConstructionCost ?? signal.constructionCost);
  if (amount == null || amount <= 0) return 0;
  if (amount >= 1000000) return 15;
  if (amount >= 250000) return 13;
  if (amount >= 100000) return 11;
  if (amount >= 50000) return 9;
  if (amount >= 25000) return 7;
  if (amount >= 10000) return 5;
  return 3;
}

function scoreSignal(signal, days = 30) {
  const text = [signal.title, signal.description, signal.category, signal.type, signal.status, signal.workType, signal.scope].join(' ');
  const matches = tradeMatches(text, signal.keywordSet);
  const recency = recencyScore(signal.date, days);
  const location = signal.lat != null && signal.lon != null ? 10 : 0;
  const detail = [signal.title, signal.description, signal.sourceRecordId, signal.organization, signal.ownerName].filter(Boolean).length;
  const trade = Math.min(25, matches.length * 8);
  const intent = intentScore(signal);
  const economic = economicScore(signal);
  const reliability = SOURCE_WEIGHT[signal.source] || 2;
  const score = Math.min(100, Math.max(0, recency + trade + intent + economic + location + Math.min(8, detail) + reliability));

  const reasonParts = [];
  if (matches.length) reasonParts.push(`${matches.slice(0, 3).join(', ')} fit`);
  if (economic) reasonParts.push('published economic value');
  if (intent >= 12) reasonParts.push('strong project intent');
  if (recency >= 18) reasonParts.push('fresh signal');
  if (location) reasonParts.push('mapped location');

  const breakdownTotal = recency + trade + intent + economic + location + Math.min(8, detail) + reliability;
  const evidenceCount = [signal.title, signal.description, signal.sourceRecordId, signal.date, signal.lat, signal.lon].filter(v => v !== null && v !== undefined && v !== '').length;
  const confidence = evidenceCount >= 5 && (matches.length || intent >= 12) ? 'HIGH' : evidenceCount >= 3 ? 'MEDIUM' : 'LOW';
  return {
    ...signal,
    score,
    confidence,
    evidenceCount,
    tradeMatches: matches,
    scoreBreakdown: { recency, trade, intent, economic, location, detail: Math.min(8, detail), reliability, totalBeforeCap: breakdownTotal },
    why: reasonParts.length ? reasonParts.join(' · ') : 'limited evidence; monitor',
    opportunityClass: classifySignal(signal),
    nextAction: nextAction(signal, matches),
  };
}

function classifySignal(signal) {
  if (signal.source === SOURCES.dataGov.id) return 'DATASET-DISCOVERY';
  const text = [signal.title, signal.description, signal.category, signal.type, signal.sourceName].join(' ').toLowerCase();
  if (/sam.gov|procurement|solicitation|contract opportunity/.test(text)) return 'PROCUREMENT';
  if (/capital|arterial|road improvement|bridge|infrastructure/.test(text)) return 'INFRASTRUCTURE';
  if (/stormwater|drainage|flood control|erosion/.test(text)) return 'SITE-WATER';
  if (/plat|subdivision|development|plan review/.test(text)) return 'DEVELOPMENT';
  if (/311|service call|graffiti|debris|weeds|dangerous building|vacant/.test(text)) return 'PROPERTY-SIGNAL';
  return 'PROJECT';
}

function nextAction(signal, matches) {
  if (signal.source === SOURCES.dataGov.id) return 'Review dataset and attach as a future acquisition source';
  if (signal.opportunityClass === 'PROCUREMENT') return 'Review solicitation, eligibility and response deadline';
  if (signal.opportunityClass === 'DEVELOPMENT') return 'Research project owner and identify trade scope';
  if (signal.opportunityClass === 'INFRASTRUCTURE') return 'Review phase, bid timing and trade subcontract path';
  if (matches.includes('tree')) return 'Verify site condition and serviceability';
  if (matches.includes('hvac')) return 'Qualify equipment/service need and decision-maker';
  return 'Qualify signal before pipeline entry';
}

function tokenSet(text) {
  return new Set(normalizeText(text).toLowerCase().replace(/[^a-z0-9]+/g, ' ').split(' ').filter(t => t.length > 2 && !STOP_WORDS.has(t)));
}

function jaccard(a, b) {
  if (!a.size || !b.size) return 0;
  let intersection = 0;
  for (const item of a) if (b.has(item)) intersection++;
  return intersection / (a.size + b.size - intersection);
}

function haversineMiles(lat1, lon1, lat2, lon2) {
  if (![lat1, lon1, lat2, lon2].every(Number.isFinite)) return Infinity;
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad;
  const dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 3958.7613 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function dedupeSignals(input) {
  const groups = [];
  const byRecord = new Map();
  for (const signal of input) {
    const recordKey = `${signal.source}:${signal.sourceRecordId || signal.id}`;
    if (!byRecord.has(recordKey)) byRecord.set(recordKey, { ...signal, provenance: [signal.source] });
    else {
      const existing = byRecord.get(recordKey);
      existing.raw = existing.raw || signal.raw;
      existing.provenance = Array.from(new Set([...(existing.provenance || []), signal.source]));
    }
  }

  const unique = Array.from(byRecord.values()).sort((a, b) => (b.score || 0) - (a.score || 0));
  for (const signal of unique) {
    const titleTokens = tokenSet(`${signal.title} ${signal.description}`);
    let merged = false;
    for (const group of groups) {
      const representative = group.items[0];
      const distance = haversineMiles(signal.lat, signal.lon, representative.lat, representative.lon);
      const sim = jaccard(titleTokens, group.tokens);
      const crossSource = signal.source !== representative.source;
      if (crossSource && distance <= 0.45 && sim >= 0.45) {
        group.items.push(signal);
        group.tokens = new Set([...group.tokens, ...titleTokens]);
        group.primary = choosePrimary(group.primary, signal);
        merged = true;
        break;
      }
    }
    if (!merged) groups.push({ tokens: titleTokens, items: [signal], primary: signal });
  }

  return groups.map(group => {
    const primary = { ...group.primary };
    const provenance = Array.from(new Set(group.items.flatMap(i => i.provenance || [i.source])));
    const corroboration = group.items.length;
    primary.corroborationCount = corroboration;
    primary.provenance = provenance;
    primary.relatedSignals = group.items.filter(i => i.id !== primary.id).map(i => ({ id: i.id, source: i.source, title: i.title, score: i.score }));
    primary.score = Math.min(100, primary.score + Math.min(8, (corroboration - 1) * 4));
    if (corroboration > 1) primary.why = `${primary.why} · corroborated by ${corroboration} sources`;
    return primary;
  }).sort((a, b) => (b.score || 0) - (a.score || 0));
}

function choosePrimary(a, b) {
  return (b.score || 0) > (a.score || 0) ? b : a;
}

function distanceFilter(signals, { lat, lon, radiusMiles }) {
  if (![lat, lon, radiusMiles].every(Number.isFinite)) return signals;
  return signals
    .map(signal => ({ ...signal, distanceMiles: haversineMiles(lat, lon, signal.lat, signal.lon) }))
    .filter(signal => signal.distanceMiles <= radiusMiles);
}

function buildHotspots(signals, radiusMiles = 0.75) {
  const groups = [];
  for (const s of signals.filter(x => Number.isFinite(x.lat) && Number.isFinite(x.lon))) {
    let group = groups.find(g => haversineMiles(g.lat, g.lon, s.lat, s.lon) <= radiusMiles);
    if (!group) {
      group = { lat: s.lat, lon: s.lon, count: 0, maxScore: 0, totalPublishedValue: 0, classes: {}, sourceIds: new Set(), signalIds: [] };
      groups.push(group);
    }
    group.count++;
    group.maxScore = Math.max(group.maxScore, s.score || 0);
    group.totalPublishedValue += normalizeNumber(s.amount ?? s.estimatedConstructionCost) || 0;
    group.classes[s.opportunityClass] = (group.classes[s.opportunityClass] || 0) + 1;
    group.sourceIds.add(s.source);
    group.signalIds.push(s.id);
    group.lat = (group.lat * (group.count - 1) + s.lat) / group.count;
    group.lon = (group.lon * (group.count - 1) + s.lon) / group.count;
  }
  return groups.map(g => ({ ...g, sourceCount: g.sourceIds.size, sourceIds: Array.from(g.sourceIds), totalPublishedValue: g.totalPublishedValue || null, densityScore: Math.min(100, g.maxScore + Math.min(35, g.count * 5) + Math.min(15, g.sourceIds.size * 5)) })).sort((a,b) => b.densityScore - a.densityScore).slice(0, 12);
}

async function fetchJson(url, options = {}, timeoutMs = 12000) {
  let attempt = 0;
  let lastError;
  while (attempt < 2) {
    attempt++;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          Accept: 'application/json',
          ...(options.headers || {}),
        },
      });
      const text = await response.text();
      let data;
      try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 2000) }; }
      if (!response.ok) {
        const retryable = response.status === 429 || response.status >= 500;
        throw Object.assign(new Error(`${response.status} ${response.statusText}: ${JSON.stringify(data).slice(0, 600)}`), { retryable, status: response.status });
      }
      return data;
    } catch (error) {
      lastError = error;
      if (!error?.retryable || attempt >= 2) break;
      await new Promise(r => setTimeout(r, 350));
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError || new Error('Fetch failed');
}

function arcgisQueryUrl(base, params) {
  const u = new URL(base);
  for (const [k, v] of Object.entries(params)) u.searchParams.set(k, String(v));
  return u.toString();
}

function centroidFromGeometry(geometry) {
  if (!geometry) return { lat: null, lon: null };
  if (Number.isFinite(geometry.y) && Number.isFinite(geometry.x)) return { lat: geometry.y, lon: geometry.x };
  const paths = geometry.paths || geometry.rings || [];
  const points = [];
  for (const part of paths) for (const point of part) if (Array.isArray(point) && Number.isFinite(point[0]) && Number.isFinite(point[1])) points.push(point);
  if (!points.length) return { lat: null, lon: null };
  return { lon: points.reduce((s,p)=>s+p[0],0)/points.length, lat: points.reduce((s,p)=>s+p[1],0)/points.length };
}

async function getSanAntonio311({ days, limit, keywords }) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const where = `OpenedDateTime >= DATE '${since.slice(0, 19).replace('T', ' ')}'`;
  const url = arcgisQueryUrl(SOURCES.sanAntonio311.url, {
    where,
    outFields: 'OBJECTID,Category,CaseID,OpenedDateTime,SLADate,ClosedDateTime,Department,ReasonName,TypeName,CaseStatus,SourceID,ObjectDescription,CouncilDistrict,ReportStartingDate,ReportEndingDate',
    returnGeometry: 'true', outSR: '4326', orderByFields: 'OpenedDateTime DESC', resultRecordCount: Math.min(limit, 2000), f: 'json',
  });
  const data = await fetchJson(url);
  const features = Array.isArray(data.features) ? data.features : [];
  return features.map(f => {
    const a = f.attributes || {}, geo = f.geometry || {};
    return scoreSignal({
      id: `cosa311:${a.OBJECTID}`, source: SOURCES.sanAntonio311.id, sourceName: SOURCES.sanAntonio311.name,
      sourceRecordId: String(a.CaseID ?? a.OBJECTID ?? ''), title: normalizeText(a.ReasonName || a.TypeName || a.Category || '311 service call'),
      description: normalizeText(a.ObjectDescription || a.TypeName || ''), category: normalizeText(a.Category), type: normalizeText(a.TypeName),
      status: normalizeText(a.CaseStatus), date: a.OpenedDateTime ? new Date(a.OpenedDateTime).toISOString() : null,
      lat: normalizeNumber(geo.y), lon: normalizeNumber(geo.x), councilDistrict: a.CouncilDistrict ?? null, keywordSet: keywords, raw: a,
    }, days);
  });
}

async function getSanAntonioPlans({ days, limit, keywords }) {
  const since = Date.now() - days * 86400000;
  const url = arcgisQueryUrl(SOURCES.sanAntonioPlans.url, {
    where: '1=1',
    outFields: 'OID,Project_Name,Record_ID,Application_Type,Application_Name,Received_Date,Type_of_Review,Project_Description,Other_Description,Street__,Pre_Direction,Street_Name,Street_Type,Post_Direction,Unit_Suite,Level_,Building,City,State,Zip_Code,Lat,Long,Parcel_s_,Council_District_s_,Neighborhood_Association_s_,School_District_s_,Master_Development_Plan_s_,San_Antonio_City_Limits,Owner_Name,Number_of_Stories,Land_Sq_Ft,Project_Square_Footage,Scheduled_Meeting_Date,Estimated_Start_Date,Estimated_Construction_Cost,DDLat,DDLon',
    returnGeometry: 'true', outSR: '4326', orderByFields: 'Received_Date DESC', resultRecordCount: Math.min(limit, 2000), f: 'json',
  });
  const data = await fetchJson(url);
  const features = Array.isArray(data.features) ? data.features : [];
  return features.filter(f => { const ms = Number(f?.attributes?.Received_Date || 0); return !ms || ms >= since; }).map(f => {
    const a = f.attributes || {}, g = centroidFromGeometry(f.geometry || {});
    return scoreSignal({
      id: `cosa-plan:${a.OID}`, source: SOURCES.sanAntonioPlans.id, sourceName: SOURCES.sanAntonioPlans.name,
      sourceRecordId: normalizeText(a.Record_ID || a.OID), title: normalizeText(a.Project_Name || a.Application_Name || 'Plan review'),
      description: normalizeText(a.Project_Description || a.Other_Description || ''), category: normalizeText(a.Application_Type), type: normalizeText(a.Type_of_Review),
      status: normalizeText(a.San_Antonio_City_Limits), date: a.Received_Date ? new Date(Number(a.Received_Date)).toISOString() : null,
      lat: normalizeNumber(a.DDLat ?? a.Lat ?? g.lat), lon: normalizeNumber(a.DDLon ?? a.Long ?? g.lon), ownerName: normalizeText(a.Owner_Name),
      amount: normalizeNumber(a.Estimated_Construction_Cost), estimatedConstructionCost: normalizeNumber(a.Estimated_Construction_Cost),
      projectSquareFootage: normalizeNumber(a.Project_Square_Footage), zip: normalizeText(a.Zip_Code), councilDistrict: normalizeText(a.Council_District_s_),
      neighborhood: normalizeText(a.Neighborhood_Association_s_), keywordSet: keywords, raw: a,
    }, days);
  });
}

async function getBexarStormwater({ days, limit, keywords }) {
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const where = `ISSUED_DATE >= DATE '${since.slice(0,19).replace('T',' ')}'`;
  const url = arcgisQueryUrl(SOURCES.bexarStormwater.url, {
    where, outFields: 'OBJECTID,ANTICIPATED_START_DATE,ANTICIPATED_STOP_DATE,CITY,ISSUED_DATE,PERMIT_NUMBER,PERMIT_STATUS,PLAT_ID,PROJECT_NAME,PROPERTY_OWNER_ADDRESS,RECEIVING_WATERS',
    returnGeometry: 'true', outSR: '4326', orderByFields: 'ISSUED_DATE DESC', resultRecordCount: Math.min(limit, 2000), f: 'json',
  });
  const data = await fetchJson(url);
  return (Array.isArray(data.features) ? data.features : []).map(f => {
    const a = f.attributes || {}, g = centroidFromGeometry(f.geometry || {});
    return scoreSignal({
      id: `bexar-storm:${a.OBJECTID}`, source: SOURCES.bexarStormwater.id, sourceName: SOURCES.bexarStormwater.name,
      sourceRecordId: normalizeText(a.PERMIT_NUMBER || a.OBJECTID), title: normalizeText(a.PROJECT_NAME || 'Stormwater permit'),
      description: normalizeText(a.PROPERTY_OWNER_ADDRESS || a.RECEIVING_WATERS || ''), category: 'Stormwater permit', type: normalizeText(a.PERMIT_STATUS),
      status: normalizeText(a.PERMIT_STATUS), date: a.ISSUED_DATE ? new Date(Number(a.ISSUED_DATE)).toISOString() : null,
      lat: g.lat, lon: g.lon, city: normalizeText(a.CITY), zip: null, keywordSet: keywords, raw: a,
    }, days);
  });
}

async function getBexarCapitalProjects({ limit, keywords }) {
  const url = arcgisQueryUrl(SOURCES.bexarCapitalProjects.url, {
    where: '1=1', outFields: 'OBJECTID,Project_ID,Location_Description,Precinct,From_Limit,To_Limit,Jurisdiction,Project_Name,Project_Phase,Funding_Type_1,Funding_Type_2,Funding_Type_3,Work_Type,Scope,Project_Status,Project_Status_Notes,Project_Progress,Project_Notes,Consultant,Design_Status,Design_Progress,Advertise_Date,Bid_Date,Joint_Bid,Contractor,Construction_Cost,Const_Cost_Notes,Construction_Start,Construction_End,Construction_Status,Construction_Progress,Primary_Project_Manager,Primary_Proj_Mgr_Email,Primary_Proj_Mgr_Phone',
    returnGeometry: 'true', outSR: '4326', resultRecordCount: Math.min(limit, 1000), f: 'json',
  });
  const data = await fetchJson(url);
  return (Array.isArray(data.features) ? data.features : []).map(f => {
    const a = f.attributes || {}, g = centroidFromGeometry(f.geometry || {});
    return scoreSignal({
      id: `bexar-capital:${a.OBJECTID}`, source: SOURCES.bexarCapitalProjects.id, sourceName: SOURCES.bexarCapitalProjects.name,
      sourceRecordId: normalizeText(a.Project_ID || a.OBJECTID), title: normalizeText(a.Project_Name || 'Bexar County capital project'),
      description: normalizeText([a.Location_Description, a.Scope, a.Project_Notes].filter(Boolean).join(' | ')), category: normalizeText(a.Work_Type),
      type: normalizeText(a.Project_Phase), status: normalizeText(a.Project_Status), date: null, lat: g.lat, lon: g.lon,
      amount: parseCurrency(a.Construction_Cost), constructionCost: parseCurrency(a.Construction_Cost), jurisdiction: normalizeText(a.Jurisdiction),
      workType: normalizeText(a.Work_Type), scope: normalizeText(a.Scope), bidDate: normalizeText(a.Bid_Date), advertiseDate: normalizeText(a.Advertise_Date),
      contractor: normalizeText(a.Contractor), manager: normalizeText(a.Primary_Project_Manager), keywordSet: keywords, raw: a,
    }, 365);
  });
}

async function getBexarPlatApplications({ days, limit, keywords }) {
  const since = new Date(Date.now() - days * 86400000);
  const where = `INIT_SUBMIT_DT >= DATE '${since.toISOString().slice(0,19).replace('T',' ')}'`;
  const url = arcgisQueryUrl(SOURCES.bexarPlatApplications.url, {
    where, outFields: 'OBJECTID,PLAT_NBR,PLAT_NM,UNIT_NBR,PHASE,SECTION_,NBR_NEW_COMMERCIAL_LOTS,NBR_NEW_SINGLE_LOTS,INIT_SUBMIT_DT,LETR_CERTIF_DT,ACEP_COMMISS_CRT_DT,PLAT_RCRD_DT,START_REVW_DT,LOCATION_DESCRIPTION,RETIRED_DT',
    returnGeometry: 'true', outSR: '4326', orderByFields: 'INIT_SUBMIT_DT DESC', resultRecordCount: Math.min(limit, 2000), f: 'json',
  });
  const data = await fetchJson(url);
  return (Array.isArray(data.features) ? data.features : []).map(f => {
    const a = f.attributes || {}, g = centroidFromGeometry(f.geometry || {});
    const commercial = normalizeNumber(a.NBR_NEW_COMMERCIAL_LOTS) || 0, single = normalizeNumber(a.NBR_NEW_SINGLE_LOTS) || 0;
    return scoreSignal({
      id: `bexar-plat:${a.OBJECTID}`, source: SOURCES.bexarPlatApplications.id, sourceName: SOURCES.bexarPlatApplications.name,
      sourceRecordId: normalizeText(a.PLAT_NBR || a.OBJECTID), title: normalizeText(a.PLAT_NM || a.PLAT_NBR || 'Plat application'),
      description: normalizeText(a.LOCATION_DESCRIPTION), category: 'Subdivision / plat', type: normalizeText(a.PHASE), status: normalizeText(a.LETR_CERTIF_DT ? 'certified' : 'under review'),
      date: a.INIT_SUBMIT_DT ? new Date(Number(a.INIT_SUBMIT_DT)).toISOString() : null, lat: g.lat, lon: g.lon,
      projectSquareFootage: null, newCommercialLots: commercial, newSingleLots: single, developerScale: commercial * 3 + single,
      keywordSet: keywords, raw: a,
    }, days);
  });
}

function parseCurrency(value) {
  if (value == null) return null;
  const cleaned = String(value).replace(/[$,\s]/g, '');
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

async function getDataGov({ q, limit }) {
  const url = new URL(SOURCES.dataGov.url); url.searchParams.set('q', q); url.searchParams.set('rows', String(Math.min(limit, 100)));
  const data = await fetchJson(url.toString());
  return (data?.result?.results || []).map(r => scoreSignal({
    id: `datagov:${r.id}`, source: SOURCES.dataGov.id, sourceName: SOURCES.dataGov.name, sourceRecordId: r.id,
    title: normalizeText(r.title), description: normalizeText(r.notes || r.description), date: r.metadata_modified || r.most_recent_update,
    url: r.access_url || r.url || null, organization: r.organization?.title || r.organization?.name || null, keywordSet: Object.keys(TRADE_TERMS), raw: r,
  }, 365));
}

async function getUSAspending({ q, limit, days }) {
  const end = new Date(), start = new Date(Date.now() - days * 86400000);
  const body = {
    filters: {
      time_period: [{ start_date: start.toISOString().slice(0, 10), end_date: end.toISOString().slice(0, 10) }],
      keywords: [q || 'San Antonio'], place_of_performance_scope: 'domestic', place_of_performance_locations: [{ country: 'USA', state: 'TX' }],
      award_type_codes: ['A', 'B', 'C', 'D'],
    },
    fields: ['Award ID','Recipient Name','Start Date','End Date','Award Amount','Awarding Agency','Awarding Sub Agency','Award Type','Description','Place of Performance City Code','Place of Performance State Code'],
    page: 1, limit: Math.min(limit, 100), sort: 'Award Amount', order: 'desc', subawards: false,
  };
  const data = await fetchJson(SOURCES.usaSpending.url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  return (Array.isArray(data.results) ? data.results : []).map(r => scoreSignal({
    id: `usaspending:${r['Award ID'] || r['Recipient Name']}`, source: SOURCES.usaSpending.id, sourceName: SOURCES.usaSpending.name,
    sourceRecordId: normalizeText(r['Award ID']), title: normalizeText(r['Description'] || r['Award Type'] || 'Federal award'),
    description: normalizeText(r['Recipient Name']), date: r['Start Date'] || r['End Date'], amount: normalizeNumber(r['Award Amount']),
    recipient: normalizeText(r['Recipient Name']), organization: normalizeText(r['Awarding Agency']), keywordSet: Object.keys(TRADE_TERMS), raw: r,
  }, days));
}

async function getSAM({ q, limit, days }) {
  const apiKey = process.env.SAM_API_KEY;
  if (!apiKey) return [];
  const postedFrom = new Date(Date.now() - days * 86400000), postedTo = new Date(), url = new URL(SOURCES.sam.url);
  url.searchParams.set('api_key', apiKey);
  url.searchParams.set('postedFrom', `${String(postedFrom.getMonth()+1).padStart(2,'0')}/${String(postedFrom.getDate()).padStart(2,'0')}/${postedFrom.getFullYear()}`);
  url.searchParams.set('postedTo', `${String(postedTo.getMonth()+1).padStart(2,'0')}/${String(postedTo.getDate()).padStart(2,'0')}/${postedTo.getFullYear()}`);
  url.searchParams.set('state', 'TX'); url.searchParams.set('title', q || 'construction'); url.searchParams.set('limit', String(Math.min(limit, 1000))); url.searchParams.set('offset', '0');
  const data = await fetchJson(url.toString());
  return (data.opportunitiesData || []).map(r => scoreSignal({
    id: `sam:${r.noticeId}`, source: SOURCES.sam.id, sourceName: SOURCES.sam.name, sourceRecordId: normalizeText(r.noticeId),
    title: normalizeText(r.title), description: normalizeText(r.description), date: r.postedDate, deadline: r.responseDeadLine,
    amount: normalizeNumber(r?.award?.amount), naicsCode: normalizeText(r.naicsCode), setAside: normalizeText(r.typeOfSetAsideDescription || r.setAside),
    location: r.placeOfPerformance?.city?.name ? `${r.placeOfPerformance.city.name}, ${r.placeOfPerformance.state?.code || 'TX'}` : null,
    url: r.uiLink || null, keywordSet: Object.keys(TRADE_TERMS), raw: r,
  }, days));
}

async function acquireSource(name, fn) {
  const started = Date.now();
  try {
    const signals = await fn();
    return { name, ok: true, ms: Date.now() - started, count: signals.length, signals };
  } catch (error) {
    return { name, ok: false, ms: Date.now() - started, count: 0, error: error?.message || String(error), signals: [] };
  }
}

function safeTradeKeywords(tradeKeywords) {
  const requested = Array.isArray(tradeKeywords) ? tradeKeywords : Object.keys(TRADE_TERMS);
  const allowed = requested.filter(k => Object.prototype.hasOwnProperty.call(TRADE_TERMS, k));
  return allowed.length ? allowed : Object.keys(TRADE_TERMS);
}

async function runRadar({ scope = 'san_antonio', q = 'San Antonio', days = 30, limit = 50, tradeKeywords = Object.keys(TRADE_TERMS), lat, lon, radiusMiles, minScore = 0 }) {
  const safeDays = Math.min(Math.max(Number(days) || 30, 1), 365);
  const safeLimit = Math.min(Math.max(Number(limit) || 50, 1), 200);
  const keywords = safeTradeKeywords(tradeKeywords);
  const centerLat = normalizeNumber(lat), centerLon = normalizeNumber(lon), radius = normalizeNumber(radiusMiles);
  const acquisitions = [];

  if (scope === 'san_antonio' || scope === 'all' || scope === 'local') {
    const local = await Promise.all([
      acquireSource('cosa-311', () => getSanAntonio311({ days: safeDays, limit: safeLimit, keywords })),
      acquireSource('cosa-plan-review', () => getSanAntonioPlans({ days: safeDays, limit: safeLimit, keywords })),
      acquireSource('bexar-stormwater', () => getBexarStormwater({ days: safeDays, limit: safeLimit, keywords })),
      acquireSource('bexar-capital-projects', () => getBexarCapitalProjects({ limit: safeLimit, keywords })),
      acquireSource('bexar-plat-applications', () => getBexarPlatApplications({ days: safeDays, limit: safeLimit, keywords })),
    ]);
    acquisitions.push(...local);
  }

  if (scope === 'all' || scope === 'federal') {
    const federal = await Promise.all([
      acquireSource('usa-spending', () => getUSAspending({ q: q || 'San Antonio', limit: safeLimit, days: safeDays })),
      acquireSource('data-gov', () => getDataGov({ q: q || 'San Antonio construction property maintenance', limit: Math.min(safeLimit, 50) })),
      acquireSource('sam-opportunities', () => getSAM({ q: q || 'construction', limit: safeLimit, days: safeDays })),
    ]);
    acquisitions.push(...federal);
  }

  let signals = dedupeSignals(acquisitions.flatMap(x => x.signals));
  const beforeGeo = signals.length;
  signals = distanceFilter(signals, { lat: centerLat, lon: centerLon, radiusMiles: radius });
  signals = signals.filter(s => (s.score || 0) >= Math.max(0, Number(minScore) || 0));
  const hotspots = buildHotspots(signals);
  const localCount = signals.filter(s => ['cosa-311','cosa-plan-review','bexar-stormwater','bexar-capital-projects','bexar-plat-applications'].includes(s.source)).length;
  const publishedValues = signals.map(s => normalizeNumber(s.amount ?? s.estimatedConstructionCost ?? s.constructionCost)).filter(n => n != null && n > 0);
  const totalPublishedValue = publishedValues.reduce((a,b)=>a+b,0) || null;
  const healthy = acquisitions.filter(x => x.ok).length;

  const sourceStatus = {};
  for (const source of Object.values(SOURCES)) {
    const acquisition = acquisitions.find(a => a.name === source.id);
    sourceStatus[source.id] = {
      ...source,
      configured: source.id === 'sam-opportunities' ? Boolean(process.env.SAM_API_KEY) : true,
      lastRun: acquisition ? { ok: acquisition.ok, ms: acquisition.ms, count: acquisition.count, error: acquisition.error || null } : null,
    };
  }

  return {
    ok: true,
    generatedAt: new Date().toISOString(),
    engineVersion: '2.0.0',
    scope, query: q, days: safeDays, returned: Math.min(signals.length, safeLimit),
    filters: { lat: centerLat, lon: centerLon, radiusMiles: radius, minScore: Number(minScore) || 0, trades: keywords },
    stats: {
      acquiredRaw: acquisitions.reduce((n,a)=>n+a.count,0), uniqueAfterDedupe: beforeGeo, returned: Math.min(signals.length,safeLimit),
      localSignals: localCount, sourceRuns: acquisitions.length, healthySources: healthy, totalSourcesAttempted: acquisitions.length,
      totalPublishedValue, hotspotCount: hotspots.length,
    },
    sourceStatus,
    sourceRuns: acquisitions.map(a => ({ source: a.name, ok: a.ok, ms: a.ms, count: a.count, error: a.error || null })),
    signals: signals.slice(0, safeLimit),
    hotspots,
    scoring: {
      version: '2.0',
      method: 'weighted evidence: recency 25 + trade fit 25 + intent 20 + published economics 15 + location 10 + record detail 8 + source reliability 5, with corroboration bonus up to 8',
      note: 'Scores rank evidence; they are not predictions. Monetary values are only passed through when published by a source.',
    },
  };
}

module.exports = { SOURCES, TRADE_TERMS, SAN_ANTONIO_CENTER, runRadar, fetchJson, haversineMiles, dedupeSignals, buildHotspots, scoreSignal };
