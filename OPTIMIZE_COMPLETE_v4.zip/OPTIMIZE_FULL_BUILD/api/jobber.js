const crypto=require('node:crypto');
const {repo,hash}=require('./_lib/db');
const {getSession}=require('./_lib/auth');
const {encrypt,decrypt}=require('./_lib/crypto');
const {json,cors}=require('./_lib/http');
const OAUTH_BASE='https://api.getjobber.com/api/oauth';
const GRAPHQL='https://api.getjobber.com/api/graphql';
function baseUrl(){return (process.env.APP_URL||'').replace(/\/$/,'');}
function required(){return ['JOBBER_CLIENT_ID','JOBBER_CLIENT_SECRET','JOBBER_REDIRECT_URI','JOBBER_GRAPHQL_VERSION','JOBBER_SCOPES','APP_ENCRYPTION_KEY'].every(k=>Boolean(process.env[k]));}
function pkce(){const verifier=crypto.randomBytes(48).toString('base64url');const challenge=crypto.createHash('sha256').update(verifier).digest('base64url');return {verifier,challenge};}
async function tokenRequest(form){const r=await fetch(`${OAUTH_BASE}/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},body:new URLSearchParams(form)});const text=await r.text();let data;try{data=JSON.parse(text)}catch{data={raw:text}}if(!r.ok)throw new Error(`JOBBER_TOKEN_${r.status}:${JSON.stringify(data).slice(0,500)}`);return data;}
async function graphql(accessToken,query,variables){const r=await fetch(GRAPHQL,{method:'POST',headers:{Authorization:`Bearer ${accessToken}`,'X-JOBBER-GRAPHQL-VERSION':process.env.JOBBER_GRAPHQL_VERSION,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({query,variables})});const data=await r.json();if(!r.ok||data.errors)throw new Error(`JOBBER_GRAPHQL_${r.status}:${JSON.stringify(data.errors||data).slice(0,800)}`);return data;}
async function refresh(integration,tenantId,r){const secret=JSON.parse(decrypt(integration.metadata.encryptedTokens));const data=await tokenRequest({client_id:process.env.JOBBER_CLIENT_ID,client_secret:process.env.JOBBER_CLIENT_SECRET,grant_type:'refresh_token',refresh_token:secret.refresh_token});const tokens={...secret,...data,received_at:Date.now()};await r.upsertIntegration(tenantId,'jobber','connected',{accountId:integration.metadata.accountId,accountName:integration.metadata.accountName,encryptedTokens:encrypt(JSON.stringify(tokens)),updatedAt:new Date().toISOString()});return tokens;}
module.exports=async function(req,res){cors(req,res);if(req.method==='OPTIONS'){res.statusCode=204;return res.end();}try{
  const session=await getSession(req); const u=new URL(req.url,'http://localhost'); const action=u.searchParams.get('action')||'';
  if(action==='callback'){
    const state=u.searchParams.get('state')||'',code=u.searchParams.get('code')||''; if(!state||!code)return json(res,400,{ok:false,error:'JOBBER_CALLBACK_MISSING'});
    const r=await repo(),st=await r.getOAuthState(hash(state)); if(!st)return json(res,400,{ok:false,error:'JOBBER_STATE_INVALID_OR_EXPIRED'}); await r.deleteOAuthState(hash(state));
    const tokens=await tokenRequest({client_id:process.env.JOBBER_CLIENT_ID,client_secret:process.env.JOBBER_CLIENT_SECRET,grant_type:'authorization_code',code,redirect_uri:process.env.JOBBER_REDIRECT_URI,code_verifier:st.verifier}); tokens.received_at=Date.now();
    const account=await graphql(tokens.access_token,'query GetAccount { account { id name } }');
    await r.upsertIntegration(st.tenant_id,'jobber','connected',{accountId:account.data?.account?.id||null,accountName:account.data?.account?.name||null,encryptedTokens:encrypt(JSON.stringify(tokens)),connectedAt:new Date().toISOString()});
    return res.writeHead(302,{Location:`${baseUrl()||'/'}/index.html?jobber=connected`}).end();
  }
  if(!session)return json(res,401,{ok:false,error:'AUTH_REQUIRED'});
  if(!required())return json(res,503,{ok:false,error:'JOBBER_NOT_CONFIGURED',required:['JOBBER_CLIENT_ID','JOBBER_CLIENT_SECRET','JOBBER_REDIRECT_URI','JOBBER_GRAPHQL_VERSION','JOBBER_SCOPES','APP_ENCRYPTION_KEY']});
  const r=await repo(); const integration=await r.getIntegration(session.tenant_id,'jobber');
  if(action==='start'){
    const {verifier,challenge}=pkce(),state=crypto.randomBytes(24).toString('base64url');await r.createOAuthState({tenantId:session.tenant_id,userId:session.user_id,provider:'jobber',stateHash:hash(state),verifier,expiresAt:new Date(Date.now()+10*60*1000).toISOString()});
    const auth=new URL(`${OAUTH_BASE}/authorize`);auth.searchParams.set('response_type','code');auth.searchParams.set('client_id',process.env.JOBBER_CLIENT_ID);auth.searchParams.set('redirect_uri',process.env.JOBBER_REDIRECT_URI);auth.searchParams.set('state',state);auth.searchParams.set('code_challenge',challenge);auth.searchParams.set('code_challenge_method','S256');auth.searchParams.set('scope',process.env.JOBBER_SCOPES);
    return res.writeHead(302,{Location:auth.toString()}).end();
  }
  if(action==='status')return json(res,200,{ok:true,configured:required(),connected:integration?.status==='connected',account:integration?.metadata?{id:integration.metadata.accountId||null,name:integration.metadata.accountName||null}:null});
  if(action==='refresh'){
    if(!integration||integration.status!=='connected')return json(res,404,{ok:false,error:'JOBBER_NOT_CONNECTED'});
    const tokens=JSON.parse(decrypt(integration.metadata.encryptedTokens));
    const exp=Number(tokens.expires_in||0);const refreshed=exp&&tokens.received_at&&Date.now() < (Number(tokens.received_at)+exp*1000-60000) ? tokens : await refresh(integration,session.tenant_id,r);return json(res,200,{ok:true,refreshed:refreshed!==tokens});
  }
  if(action==='account'){
    if(!integration?.metadata?.encryptedTokens)return json(res,404,{ok:false,error:'JOBBER_NOT_CONNECTED'});
    let tokens=JSON.parse(decrypt(integration.metadata.encryptedTokens));
    const expiresAt=Number(tokens.received_at||0)+Number(tokens.expires_in||3600)*1000;
    if(Date.now()>expiresAt-60000){tokens=await refresh(integration,session.tenant_id,r);tokens.received_at=Date.now();}
    return json(res,200,{ok:true,data:await graphql(tokens.access_token,'query GetAccount { account { id name } }')});
  }
  return json(res,400,{ok:false,error:'UNKNOWN_ACTION'});
}catch(e){return json(res,502,{ok:false,error:e.message||String(e)});}};
