const { repo } = require('./_lib/db');
const { hashPassword, verifyPassword, strongEnough, loginSession, destroySession, getSession } = require('./_lib/auth');
const { json, cors, readBody } = require('./_lib/http');

module.exports = async function handler(req,res){
  cors(req,res);
  if(req.method==='OPTIONS'){res.statusCode=204;return res.end();}
  const r=await repo();
  try{
    if(req.method==='GET'){
      const s=await getSession(req);
      return json(res,200,{ok:true,user:s?{id:s.user_id,email:s.email,name:s.name,tenantId:s.tenant_id}:null, persistent:r.persistent});
    }
    if(req.method!=='POST')return json(res,405,{ok:false,error:'METHOD_NOT_ALLOWED'});
    const body=await readBody(req),action=body.action;
    if(action==='logout'){await destroySession(req,res);return json(res,200,{ok:true});}
    if(action==='signup'){
      const name=String(body.name||'').trim(),email=String(body.email||'').trim().toLowerCase(),password=String(body.password||''),tenantName=String(body.tenantName||name||'OPTIMIZE Tenant').trim();
      if(!name||!email.includes('@')||!strongEnough(password))return json(res,400,{ok:false,error:'NAME_EMAIL_PASSWORD_REQUIRED'});
      if(await r.getUserByEmail(email))return json(res,409,{ok:false,error:'EMAIL_EXISTS'});
      const created=await r.createUserWithTenant({email,name,passwordHash:hashPassword(password),tenantName});
      await loginSession(req,res,created.userId);
      return json(res,201,{ok:true,user:{id:created.userId,email,name,tenantId:created.tenantId},persistent:r.persistent});
    }
    if(action==='login'){
      const email=String(body.email||'').trim().toLowerCase(),password=String(body.password||'');
      const u=await r.getUserByEmail(email);
      if(!u||!verifyPassword(password,u.password_hash))return json(res,401,{ok:false,error:'INVALID_CREDENTIALS'});
      await loginSession(req,res,u.id);
      return json(res,200,{ok:true,user:{id:u.id,email:u.email,name:u.name,tenantId:u.tenant_id},persistent:r.persistent});
    }
    return json(res,400,{ok:false,error:'UNKNOWN_ACTION'});
  }catch(e){return json(res,500,{ok:false,error:e.message||String(e)});}
};
