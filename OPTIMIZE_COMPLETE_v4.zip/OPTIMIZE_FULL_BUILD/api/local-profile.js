const { SAN_ANTONIO_CENTER, SOURCES, TRADE_TERMS } = require('./_lib/radar');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGIN || req.headers?.origin || '*');
  res.setHeader('Vary', 'Origin');
  if (req.method !== 'GET') { res.statusCode = 405; return res.end(JSON.stringify({ ok: false, error: 'GET only' })); }
  res.statusCode = 200;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify({
    ok: true,
    profile: 'san_antonio',
    center: SAN_ANTONIO_CENTER,
    localSources: Object.values(SOURCES).filter(s => ['city','county'].includes(s.kind)).map(s => ({ id: s.id, name: s.name, capabilities: s.capabilities, url: s.url })),
    tradeVocabulary: Object.keys(TRADE_TERMS),
    recommendedRadiusMiles: [1, 3, 5, 10, 25],
  }));
};
