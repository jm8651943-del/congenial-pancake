const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]).filter(f=>f.endsWith('.js'))}
for(const f of files(path.join(process.cwd(),'api')).concat([path.join(process.cwd(),'local-server.js'),path.join(process.cwd(),'scripts-migrate.js')])){const r=cp.spawnSync(process.execPath,['--check',f],{encoding:'utf8'});if(r.status!==0){console.error(r.stderr);process.exit(r.status||1)}}console.log('JS syntax checks: PASS');
