const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const temp=path.join(os.tmpdir(),`optimize-${process.pid}-${Date.now()}.json`);process.env.LOCAL_DATA_PATH=temp;process.env.RADAR_REQUIRE_AUTH='false';
function response(){return{statusCode:200,headers:{},body:'',setHeader(k,v){this.headers[k]=v},end(v){this.body=v??''},writeHead(code,headers){this.statusCode=code;this.headers={...this.headers,...headers};return this},}};
function req(method,body,cookie=''){return{method,body,headers:cookie?{cookie}: {},url:'/api/test'}}
function parsed(res){return JSON.parse(res.body||'{}')}
(async()=>{
 const auth=require('../api/auth'),opp=require('../api/opportunities'),tasks=require('../api/tasks'),dash=require('../api/dashboard');
 let res=response();await auth(req('POST',{action:'signup',name:'Tester',tenantName:'Test Tenant',email:'tester@example.com',password:'password123'}),res);assert.equal(res.statusCode,201);let data=parsed(res);assert.ok(data.user.tenantId);const cookie=res.headers['Set-Cookie'];assert.ok(cookie.includes('optimize_session='));
 res=response();await auth(req('GET',{},cookie),res);assert.equal(parsed(res).user.email,'tester@example.com');
 res=response();await opp(req('POST',{title:'HVAC opportunity',company:'Example Co',status:'QUALIFIED',score:91,amount:25000,trades:['hvac']} ,cookie),res);assert.equal(res.statusCode,201);const oid=parsed(res).item.id;
 res=response();await opp({...req('PATCH',{status:'CONTACTED'},cookie),url:`/api/opportunities?id=${oid}`},res);assert.equal(parsed(res).item.status,'CONTACTED');
 res=response();await tasks(req('POST',{title:'Call Example Co',priority:'HIGH'},cookie),res);assert.equal(res.statusCode,201);const tid=parsed(res).item.id;
 res=response();await tasks({...req('PATCH',{status:'DONE'},cookie),url:`/api/tasks?id=${tid}`},res);assert.equal(parsed(res).item.status,'DONE');
 res=response();await dash(req('GET',{},cookie),res);const dd=parsed(res);assert.equal(dd.ok,true);assert.equal(dd.dashboard.openTasks,0);assert.equal(dd.opportunities.length,1);
 // Second account must not see first account's records.
 res=response();await auth(req('POST',{action:'signup',name:'Other',tenantName:'Other Tenant',email:'other@example.com',password:'password123'}),res);const otherCookie=res.headers['Set-Cookie'];
 res=response();await opp(req('GET',{},otherCookie),res);assert.equal(parsed(res).items.length,0);
 console.log('Auth + persistence integration: PASS');
 if(fs.existsSync(temp))fs.unlinkSync(temp);
})().catch(e=>{console.error(e);if(fs.existsSync(temp))fs.unlinkSync(temp);process.exit(1)});
