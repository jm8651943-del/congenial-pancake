# OPTIMIZE Unified v4.0.0

A consolidated OPTIMIZE application build that closes the missing product layers around the acquisition/radar engine.

## Included

- Functional customer command center in `index.html`.
- Enhanced launcher in `OPTIMIZE_Launcher_Enhanced.html`.
- Multi-tenant account/session auth.
- Persistent opportunity, task, activity, radar-scan and integration records.
- Neon/Postgres repository with local JSON development fallback.
- Live San Antonio + Bexar County acquisition feeds and federal sources.
- Explainable ranking, cross-source corroboration, geospatial filtering and hotspot clustering.
- Promote-from-radar workflow into the persistent pipeline.
- Jobber OAuth 2.0 + PKCE + encrypted token storage + refresh handling.
- Google Business and QuickBooks OAuth entry points with encrypted token storage.
- Stripe subscription checkout, portal and subscription sync routes.
- Six-hour scheduled radar route in `api/cron/radar.js`.
- PWA manifest + service worker.
- Tenant JSON export.
- Vercel Node 22 configuration.
- Offline verification suite in `tests/`.

## Core flow

Browser → auth session → OPTIMIZE API → persistent database → radar acquisition → normalization → scoring → deduplication/corroboration → geo hotspots → promotion → pipeline → tasks/activities → export.

## Local development

Without `DATABASE_URL`, the application stores local development state in `data/optimize.local.json`.

```bash
npm install
npm run db:init
npm run serve
```

Windows users can double-click `START_OPTIMIZE_LOCAL.bat`; PowerShell users can run `START_OPTIMIZE_LOCAL.ps1`.


Open `http://127.0.0.1:8787/`.

Production should use Postgres; the JSON fallback is intentionally a development convenience rather than a durable cloud database.

## Vercel + Neon

The intended production storage layer is Neon Postgres through Vercel's current storage marketplace. Vercel documents the Neon integration and `DATABASE_URL` workflow here: https://vercel.com/marketplace/neon/neon

`api/_lib/db.js` initializes the schema automatically on first use.

## Credentials and security

Never place provider secrets in browser code or localStorage.

Required production secrets are documented in `.env.example` and include:

- `DATABASE_URL`
- `APP_ENCRYPTION_KEY`
- `APP_SECRET`
- `SAM_API_KEY` when SAM acquisition is desired
- Jobber OAuth variables
- Google/QuickBooks OAuth variables when those integrations are desired
- Stripe variables when billing is desired
- `CRON_SECRET` for the scheduled scanner

Provider tokens are encrypted with AES-GCM. Token encryption fails closed when `APP_ENCRYPTION_KEY` is absent.

## Jobber

Jobber's developer documentation specifies OAuth 2.0 authorization-code flow, PKCE support, server-side client-secret handling, refresh-token rotation, and a dated GraphQL API version header. The implementation keeps those values server-side and requires `JOBBER_GRAPHQL_VERSION` and `JOBBER_SCOPES` from the environment: https://developer.getjobber.com/docs/building_your_app/app_authorization/

## Radar and San Antonio

The radar uses the San Antonio/Bexar source set already established in the acquisition gateway and stores each authenticated scan plus normalized evidence. Published dollar values are carried through only when the source publishes them; scoring ranks evidence and does not predict outcomes.

## Verification

```bash
npm test
npm run check
```

The build was also exercised through a local HTTP smoke test covering `/api/health`, account creation, authenticated opportunity creation and dashboard retrieval.

## Owner-controlled production setup

The code is consolidated and testable, but external resources still require the owner to connect them: the Vercel project, Neon database, provider developer apps/callback URLs, and credentials. No deployment, publish, or credential creation is performed by this package itself.
