$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 22+ is required.' }
if (-not (Test-Path node_modules)) { npm install }
$env:PORT='8787'
$env:RADAR_REQUIRE_AUTH='false'
Start-Process powershell -ArgumentList '-NoExit','-Command','node local-server.js' -WorkingDirectory $PSScriptRoot
Start-Sleep -Seconds 2
Start-Process 'http://127.0.0.1:8787/'
