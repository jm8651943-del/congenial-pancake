@echo off
setlocal
cd /d %~dp0
where node >nul 2>nul || (echo Node.js 22+ is required. & pause & exit /b 1)
if not exist node_modules (@echo Installing dependencies... & call npm install || exit /b 1)
set PORT=8787
set RADAR_REQUIRE_AUTH=false
start "OPTIMIZE" cmd /k "node local-server.js"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8787/
