SOURCE VALIDATION NOTES

San Antonio official Development Services pages state that Open Data SA includes 311 calls for service, permitting data and a broad GIS dataset catalog; its reports page lists building permit applications/issuances, preliminary plan reviews and variance requests.

Bexar County ArcGIS REST documentation exposes stormwater permits, capital projects, and plat application layers. Capital projects are described as flood control, arterial expansion and road improvement projects with monthly updates on the 15th or as needed. Stormwater permits represent project locations and are updated as needed. Plat Applications exposes commercial/single-family lot counts and application dates.

SEC's official API documentation confirms data.sec.gov submissions APIs are public/no-key, updated in real time, and do not support CORS; automated access must comply with SEC fair-access requirements.
