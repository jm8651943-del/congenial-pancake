# OPTIMIZE Live Acquisition Gateway — 2.0.0

This package is the server-side acquisition and radar layer for OPTIMIZE. It is designed for Vercel's Node.js runtime and keeps credentialed API access out of browser code.

## What changed in 2.0

- Parallel acquisition across local, county, and federal connectors.
- San Antonio + Bexar local signal layer.
- Cross-source deduplication and corroboration tracking.
- Geospatial radius filtering and hotspot clustering.
- Explainable evidence scoring with confidence tiers.
- Per-source runtime, success/error, and record-count telemetry.
- Safer fetch behavior with timeouts and a retry for transient 429/5xx responses.
- Expanded trade vocabulary for HVAC, plumbing, electrical, roofing, tree/brush, exterior, property maintenance, construction, stormwater, and infrastructure.
- Local profile endpoint for source discovery and trade vocabulary.
- CORS handling for GET/OPTIONS and explicit server-side secret handling.

## Endpoints

- `GET /api/health` — gateway health/capability metadata.
- `GET /api/sources` — machine-readable source registry and connector configuration state.
- `GET /api/local-profile` — San Antonio/Bexar profile, local sources, trade vocabulary, recommended search radii.
- `GET /api/radar` — acquisition + normalization + scoring + dedupe + geo filter + hotspots.
- `GET /api/city-catalog?q=building%20permits` — City of San Antonio open-data catalog discovery proxy.
- `GET /api/sec?cik=##########` — server-side SEC submissions lookup.

## Radar parameters

`/api/radar` accepts:

- `scope=san_antonio|local|federal|all`
- `q=<search terms>`
- `days=1..365`
- `limit=1..200`
- `minScore=0..100`
- `trades=hvac,plumbing,...`
- `lat=<latitude>` and `lon=<longitude>`
- `radiusMiles=<miles>`

Example:

`/api/radar?scope=san_antonio&q=HVAC%20construction&days=30&limit=50&trades=hvac,construction`

Radius example around central San Antonio:

`/api/radar?scope=san_antonio&q=property%20maintenance&days=30&radiusMiles=5`

## Local sources attached

### City of San Antonio

- 311 All Service Calls — mapped service-request signals.
- Preliminary Plan Review Meetings — development/project signals, including owner, project description, location fields, square footage, and estimated construction cost when published.
- Open Data Search API — dataset discovery for future adapters.

The City's Development Services pages state that Open Data SA includes 311 calls, permitting data, and an extensive GIS catalog. The City's reports page lists building permit applications/issuances, preliminary plan reviews, and variance requests among its open-data reporting groups.

### Bexar County

- Stormwater permits — project location and permit status; county notes updates occur as needed.
- Capital projects — public-works CIP projects. The county describes the layer as covering flood control, arterial expansion, and road improvements and notes monthly updates on the 15th or as needed.
- Plat applications — development/subdivision signals, including commercial and single-family lot counts and application dates.

## Federal sources

Public/no browser key:

- USAspending API.
- Data.gov catalog.
- SEC EDGAR data.sec.gov (server-side; identify automated requests with an appropriate User-Agent).

Credentialed:

- SAM.gov Opportunities V2 API (`SAM_API_KEY`).

## Scoring

The 2.0 evidence score uses:

- Recency: up to 25
- Trade fit: up to 25
- Project intent: up to 20
- Published economic value: up to 15
- Mapped location: 10
- Record detail: up to 8
- Source reliability: up to 5
- Cross-source corroboration bonus: up to 8

The score is a ranking aid for evidence, not a prediction. OPTIMIZE passes through monetary amounts only when a source publishes them.

## Security

Never place `SAM_API_KEY`, `SEC_USER_AGENT`, or other credentials in static HTML or browser localStorage. Set them in Vercel project environment variables.

For production, set `ALLOWED_ORIGIN` to the exact OPTIMIZE web origin rather than leaving it open.

## Verification

The included checks are offline and deterministic:

- `node test-radar.js`
- `node test-gateway.js`
- `node --check api/_lib/radar.js`
- `node --check api/radar.js`
- `node --check api/sources.js`
- `node --check api/health.js`
- `node --check api/local-profile.js`
- `node --check api/sec.js`
