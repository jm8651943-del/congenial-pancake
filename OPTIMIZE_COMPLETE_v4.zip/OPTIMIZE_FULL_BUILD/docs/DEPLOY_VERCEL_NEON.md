# OPTIMIZE deployment: Vercel + Neon

1. Put this project in the `primeforgesole-cloud/OPTIMIZE` repository.
2. In Vercel, connect the repository as a project.
3. Add Neon Postgres through the Vercel Marketplace. The current Vercel storage marketplace supports Neon and supplies the database connection variable to the project. See the official Vercel/Neon integration: https://vercel.com/marketplace/neon/neon
4. Pull the environment into local development with `vercel env pull` or copy the values into `.env`.
5. Add the remaining server-side variables from `.env.example` in Vercel Project Settings → Environment Variables.
6. Keep `SAM_API_KEY`, provider client secrets, Stripe secret keys, and `APP_ENCRYPTION_KEY` server-side only.
7. Deploy. The app routes `/` to `index.html`, and Vercel runs `api/*.js` as Node 22 functions.
8. Verify `/api/health`, create the first account, then run a San Antonio radar scan.

### Database

`api/_lib/db.js` automatically initializes the Postgres schema on first use. For local development without `DATABASE_URL`, it falls back to `data/optimize.local.json` so the full app can still be exercised.

Production should use Neon/Postgres rather than the JSON fallback because Vercel function filesystems are not an appropriate durable application database.

### Jobber

Jobber uses OAuth 2.0, not static API keys. The app's OAuth callback is `/api/jobber?action=callback`; set the exact callback URL in the Jobber Developer Center. Jobber requires an active dated GraphQL API version on every GraphQL request, supplied via `JOBBER_GRAPHQL_VERSION`. Official docs: https://developer.getjobber.com/docs/building_your_app/app_authorization/

### Scheduled radar

`vercel.json` includes `/api/cron/radar` every six hours. Set `CRON_SECRET`. The cron route scans up to 20 tenants and saves the resulting evidence. Adjust the query/scope variables in `.env.example` as needed.
